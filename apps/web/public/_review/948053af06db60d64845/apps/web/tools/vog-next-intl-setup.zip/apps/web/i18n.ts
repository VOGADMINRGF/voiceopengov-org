export const locales = ["de", "en", "fr", "es", "pl", "ar", "ru"] as const;
export const defaultLocale = "de";
